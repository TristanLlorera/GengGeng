<?php




$conn = mysqli_connect("localhost","root","","cornhub")
        or die("Error 404");






?>